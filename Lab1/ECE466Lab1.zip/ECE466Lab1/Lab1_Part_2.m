clc;clear all;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Reading data from the file
%Note: - time is in miliseconds and framesize is in Bytes
%      - file is sorted in transmit sequence
%  Column 1:   index of frame (in display sequence)
%  Column 2:   time of frame in ms (in display sequence)
%  Column 3:   type of frame (I, P, B)
%  Column 4:   size of frame (in Bytes)
%  Column 5-7: not used
%
% Since we are interested in the transmit sequence we ignore Columns 1 and
% 2. So, we are only interested in the following columns: 
%       Column 3:  assigned to type_f
%       Column 4:   assigned to framesize_f
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[index, time, type_f, framesize_f, dummy1, dymmy2, dymmy3 ] = textread('movietrace.data', '%f %f %c %f %f %f %f');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   CODE FOR EXERCISE 2.2   (version: Spring 2007)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Extracting the I,P,B frmes characteristics from the source file
%frame size of I frames  : framesize_I
%frame size of P frames  : framesize_p 
%frame size of B frames  : framesize_B
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

a=0;
b=0;
c=0;
for i=1:length(index)
    if type_f(i)=='I'
        a=a+1;
        framesize_I(a)=framesize_f(i);
    end
     if type_f(i)=='B'
         b=b+1;
         framesize_B(b)=framesize_f(i);
         end
     if type_f(i)=='P'
         c=c+1;
         framesize_P(c)=framesize_f(i);
     end     

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Hint1: You may use the MATLAB functions 'length()','mean()','max()','min()'.
%       which calculate the length,mean,max,min of a
%       vector (for example max(framesize_P) will give you the size of
%       largest P frame
%Hint2: Use the 'plot' function to graph the framesize as a function of the frame
%       sequence number. 
%Hint3: Use the function 'hist' to show the distribution of the frames. Before 
%       that function type 'figure(2);' to indicate your figure number.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
mean_f=mean(framesize_f);
sum_f=sum(framesize_f);
len_f=length(framesize_f);
max_f=max(framesize_f);
min_f=min(framesize_f);
fprintf('number of all frames= %i frames\n',len_f);
fprintf('total size of all frames= %i bytes\n',sum_f);
fprintf('mean of all frames= %i bytes\n',mean_f);
fprintf('max of all frames= %i bytes\n',max_f);
fprintf('min of all frames= %i bytes\n',min_f);

mean_I=mean(framesize_I);
len_I=length(framesize_I);
max_I=max(framesize_I);
min_I=min(framesize_I);
fprintf('I length = %i frames\n',len_I);
fprintf('I mean = %i bytes\n',mean_I);
fprintf('I max = %i bytes\n',max_I);
fprintf('I min = %i bytes\n',min_I);

mean_B=mean(framesize_B);
len_B=length(framesize_B);
max_B=max(framesize_B);
min_B=min(framesize_B);
fprintf('B length = %i frames\n',len_B);
fprintf('B mean = %i bytes\n',mean_B);
fprintf('B max = %i bytes\n',max_B);
fprintf('B min = %i bytes\n',min_B);

mean_P=mean(framesize_P);
len_P=length(framesize_P);
max_P=max(framesize_P);
min_P=min(framesize_P);
fprintf('P length = %i frames\n',len_P);
fprintf('P mean = %i bytes\n',mean_P);
fprintf('P max = %i bytes\n',max_P);
fprintf('P min = %i bytes\n',min_P);

mean_bit_rate = (mean_f*8/1000000)/0.033;
peak_bit_rate = (max_f*8/1000000)/0.033;
peak_to_avg = peak_bit_rate/mean_bit_rate;
fprintf('mean bit rate = %i Mbps\npeak bit rate = %i Mbps\npeak-to-average rate ratio = %i\n', mean_bit_rate, peak_bit_rate, peak_to_avg);

plot1 = plot(index, framesize_f);title('frame size vs frame sequence number'); ylabel('size(Bytes)'); xlabel('sequence number');
figure(2);
subplot(3,1,1);hist(framesize_I);title('I distribution');xlabel('frame size(Bytes)'); ylabel('frequency');
subplot(3,1,2);hist(framesize_P);title('P distribution');xlabel('frame size(Bytes)'); ylabel('frequency');
subplot(3,1,3);hist(framesize_B);title('B distribution');xlabel('frame size(Bytes)'); ylabel('frequency');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   CODE FOR EXERCISE 2.3   (version: Spring 2007)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%The following code will generates Plot 1. You generate Plot2 , Plot3 on
%your own. 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% The next line assigns a label (figure number) to the figure 
figure(3);

initial_point=1;
ag_frame=500;
jj=initial_point;
i=1;
bytes_f=zeros(1,100);
while i<=100
while ((jj-initial_point)<=ag_frame*i && jj<length(framesize_f))
bytes_f(i)=bytes_f(i)+framesize_f(jj);
jj=jj+1;
end
i=i+1;
end
subplot(3,1,1);bar(bytes_f);title('plot 1'); xlabel('500 frames'); ylabel('Frequency');


initial_point=3000;
ag_frame=50;
jj=initial_point;
i=1;
bytes_f=zeros(1,100);
while i<=100
while ((jj-initial_point)<=ag_frame*i && jj<length(framesize_f))
bytes_f(i)=bytes_f(i)+framesize_f(jj);
jj=jj+1;
end
i=i+1;
end
subplot(3,1,2);bar(bytes_f);title('plot 2');xlabel('50 frames'); ylabel('Frequency');


initial_point=5010;
ag_frame=5;
jj=initial_point;
i=1;
bytes_f=zeros(1,100);
while i<=100
while ((jj-initial_point)<=ag_frame*i && jj<length(framesize_f))
bytes_f(i)=bytes_f(i)+framesize_f(jj);
jj=jj+1;
end
i=i+1;
end
subplot(3,1,3);bar(bytes_f);title('plot 3');xlabel('5 frames'); ylabel('Frequency');