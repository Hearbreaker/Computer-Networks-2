clc;clear all;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Reading the data and putting the first 100000 entries in variables 
%Note that time is in seconds and framesize is in Bytes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
no_entries=100000;
[time1, framesize1] = textread('BC-pAug89.TL', '%f %f');
time=time1(1:no_entries);
framesize=framesize1(1:no_entries);

%%%%%%%Exercise 3.2

num_packets=length(framesize1);
sum_size=sum(framesize1);
mean_bit_rate=(sum_size*8/1000000)/time1(num_packets);
for j=1:num_packets
    if(j == 1)
        inst_rate(j)=framesize1(j)/time1(j);
    end
    if(j ~= 1)
        inst_rate(j)=framesize1(j)/(time1(j)-time1(j-1));
    end
end
peak_bit_rate=(max(inst_rate)*8/1000000);
peak_to_mean_ratio=peak_bit_rate/mean_bit_rate;
fprintf('number of packets captured = %i\n',num_packets);
fprintf('total size = %i bytes\n', sum_size);
fprintf('mean bit rate = %i Mbps\n', mean_bit_rate);
fprintf('peak bit rate = %i Mbps\n', peak_bit_rate);
fprintf('peak rate to average rate ratio = %i \n', peak_to_mean_ratio);

figure(1);
subplot(2,1,1);plot(time1,framesize1);title('frame size vs time'); xlabel('time(s)'); ylabel('size(byte)')
subplot(2,1,2);hist(framesize1);title('distribution of packet sizes'); xlabel('packet size(byte)'); ylabel('frequency');
%%%%%%%%%%%%%%%%%%%%%%%%%Exercise %%%3.3%%%%%%%%%%%%%%%%%%%%%%%%%%%
%The following code will generate Plot 1; You generate Plot2 , Plot3.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(2);
jj=1;
i=1;
initial_p=0;
ag_time=1;
bytes_p=zeros(1,100);
while time(jj)<=initial_p
    jj=jj+1;
end
while i<=100
while ((time(jj)-initial_p)<=ag_time*i && jj<no_entries)
bytes_p(i)=bytes_p(i)+framesize(jj);
jj=jj+1;
end
i=i+1;
end
%%%%%%%%
subplot(3,1,1);bar(bytes_p);title('plot 1'); ylabel('number of bytes'); xlabel('Element Number(1s of traffic per element)');

jj=1;
i=1;
initial_p=20;
ag_time=0.1;
bytes_p=zeros(1,100);
while time(jj)<=initial_p
    jj=jj+1;
end
while i<=100
while ((time(jj)-initial_p)<=ag_time*i && jj<no_entries)
bytes_p(i)=bytes_p(i)+framesize(jj);
jj=jj+1;
end
i=i+1;
end
%%%%%%%%
subplot(3,1,2);bar(bytes_p);title('plot 2');ylabel('number of bytes'); xlabel('Element Number(100ms of traffic per element)');

jj=1;
i=1;
initial_p=90;
ag_time=0.01;
bytes_p=zeros(1,100);
while time(jj)<=initial_p
    jj=jj+1;
end
while i<=100
while ((time(jj)-initial_p)<=ag_time*i && jj<no_entries)
bytes_p(i)=bytes_p(i)+framesize(jj);
jj=jj+1;
end
i=i+1;
end
%%%%%%%%
subplot(3,1,3);bar(bytes_p);title('plot 3');ylabel('number of bytes'); xlabel('Element Number(10ms of traffic per element)');


